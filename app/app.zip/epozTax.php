<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class epozTax extends Model
{
    protected $fillable = [
        'tax',
    ];
}
