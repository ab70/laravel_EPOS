<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class epozDiscount extends Model
{
    
    protected $fillable = [
        'discount','discount_offer'
    ];
}
