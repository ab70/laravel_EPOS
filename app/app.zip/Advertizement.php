<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Advertizement extends Model
{
    protected $fillable = [
        'name','file'
    ];
}
